package com.zosh.domain;

public enum HomeCategorySection {
    ELECTRIC_CATEGORIES,
    GRID,
    SHOP_BY_CATEGORIES,
    DEALS
}
