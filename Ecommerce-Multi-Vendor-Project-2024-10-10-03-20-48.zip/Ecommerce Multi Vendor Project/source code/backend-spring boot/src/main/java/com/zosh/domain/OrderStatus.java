package com.zosh.domain;

public enum OrderStatus {
    PENDING,
    PLACED,
    CONFIRMED,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
