package com.zosh.domain;

public enum PayoutsStatus {
    PENDING,
    SUCCESS
}
