package com.zosh.domain;

public enum USER_ROLE {
	

	    ROLE_CUSTOMER,
	    ROLE_SELLER,
	    ROLE_ADMIN
	


}
