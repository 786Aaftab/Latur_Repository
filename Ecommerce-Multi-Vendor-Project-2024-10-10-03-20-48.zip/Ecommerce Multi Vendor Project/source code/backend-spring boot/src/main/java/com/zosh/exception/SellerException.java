package com.zosh.exception;

public class SellerException extends Exception {

    public SellerException(String message) {
        super(message);
    }


}
