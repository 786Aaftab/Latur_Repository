package com.zosh.exception;

public class ShopNotFoundException extends Exception {
    public ShopNotFoundException(String message) {
        super(message);
    }
}
