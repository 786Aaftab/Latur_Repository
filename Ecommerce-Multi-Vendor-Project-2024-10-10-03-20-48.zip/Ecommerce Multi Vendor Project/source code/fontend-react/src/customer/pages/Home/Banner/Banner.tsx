import React from 'react'

const Banner = () => {
  return (
    <div>
        <img src="https://www.libas.in/cdn/shop/files/eoss-desktop.jpg?v=1719849154&width=1920" alt="" />
    </div>
  )
}

export default Banner