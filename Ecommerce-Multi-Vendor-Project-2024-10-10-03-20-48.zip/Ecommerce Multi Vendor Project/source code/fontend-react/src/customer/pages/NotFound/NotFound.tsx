import React from 'react'

const NotFound = () => {
  return (
    <div className='h-screen flex justify-center items-center'>
        <h1 className='text-xl lg:text-5xl font-bold'>Page Not Found</h1>
    </div>
  )
}

export default NotFound