export const productDetailsData={
    images:[
        "https://www.karagiri.com/cdn/shop/products/patola-saree-hot-pink-patola-saree-silk-saree-online-32261950898369.jpg?v=1704965372",
        "https://www.karagiri.com/cdn/shop/products/patola-saree-hot-pink-patola-saree-silk-saree-online-32261950996673_540x.jpg?v=1704965372",
        "https://www.karagiri.com/cdn/shop/products/patola-saree-hot-pink-patola-saree-silk-saree-online-32261950931137_540x.jpg?v=1704965372",
        "https://www.karagiri.com/cdn/shop/products/patola-saree-hot-pink-patola-saree-silk-saree-online-32261951029441_540x.jpg?v=1704965372",
        "https://www.karagiri.com/cdn/shop/products/patola-saree-hot-pink-patola-saree-silk-saree-online-32261950865601_540x.jpg?v=1704965372"
    ]
}