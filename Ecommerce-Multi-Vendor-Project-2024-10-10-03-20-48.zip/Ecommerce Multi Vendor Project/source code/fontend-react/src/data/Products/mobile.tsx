
import React from 'react'

const Mobile = () => {
  return (
    <div>
        <ul>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/5/i/7/-original-imahfu766ybd5h4z.jpeg?q=70&crop=false" target="_blank">Image 1</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/o/s/c/-original-imagx9pfuguwhfhe.jpeg?q=70&crop=false" target="_blank">Image 2</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/t/q/k/-original-imagx9pff4gxepfy.jpeg?q=70&crop=false" target="_blank">Image 3</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/r/f/y/-original-imagx9pf7dd5ny7n.jpeg?q=70&crop=false" target="_blank">Image 4</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/v/b/h/-original-imagx9pfdevtsjey.jpeg?q=70&crop=false" target="_blank">Image 5</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/n/5/d/-original-imagy63spzffxgcg.jpeg?q=70&crop=false" target="_blank">Image 6</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/k/6/r/-original-imagx9egwjgtgwqf.jpeg?q=70&crop=false" target="_blank">Image 7</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/1/t/a/-original-imagx9egkfqux8qh.jpeg?q=70&crop=false" target="_blank">Image 8</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/i/u/o/-original-imagx9egvraqxfeh.jpeg?q=70&crop=false" target="_blank">Image 9</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/5/u/a/-original-imagx9egd2csrur5.jpeg?q=70&crop=false" target="_blank">Image 10</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/h/a/c/-original-imagx9eghmmcbpup.jpeg?q=70&crop=false" target="_blank">Image 11</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/x/r/u/-original-imagx9egxcyjzvux.jpeg?q=70&crop=false" target="_blank">Image 12</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/s/j/i/-original-imagx9egdetafafz.jpeg?q=70&crop=false" target="_blank">Image 13</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/i/r/f/-original-imagx9egbpzh8bhu.jpeg?q=70&crop=false" target="_blank">Image 14</a></li>
    <li><a href="https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/s/y/i/-original-imahfu769c4auwdg.jpeg?q=70&crop=false" target="_blank">Image 15</a></li>
</ul>
    </div>
  )
}

export default Mobile