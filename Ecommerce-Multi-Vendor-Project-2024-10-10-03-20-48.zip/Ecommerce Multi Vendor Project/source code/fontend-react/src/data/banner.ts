export const banners = [
  "https://www.taneira.com/dw/image/v2/BKMH_PRD/on/demandware.static/-/Sites-Taneira-Library/default/dw53b6ec27/HomePage/Banners/Apsara/N_Apsara_WebBanners_1920x768_D.jpg",

  "https://www.taneira.com/dw/image/v2/BKMH_PRD/on/demandware.static/-/Sites-Taneira-Library/default/dwdc296071/HomePage/Banners/Queens/HP_Queen_D.jpg",

  [
    "https://www.taneira.com/on/demandware.static/-/Sites-Taneira-Library/default/dwbc5a4d1c/images/login_signup/Login_COI.jpg",
  ],
];
