import React from 'react'

const Invetory = () => {
  return (
    <div>Invetory</div>
  )
}

export default Invetory