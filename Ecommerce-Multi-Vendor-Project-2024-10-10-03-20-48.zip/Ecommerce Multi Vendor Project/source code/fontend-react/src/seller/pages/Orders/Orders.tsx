import React from 'react'
import OrderTable from './OrderTable'

const Orders = () => {
  return (
    <div>
      <OrderTable/>
    </div>
  )
}

export default Orders